import axios from 'axios';

export default function employeeDetails () {
    const url = "http://localhost:3333/userDetails/";
    let config = {
        method: 'POST',
        url: '',
        headers: {
            'Content-Type': 'application/json'
        },
        data: ''
    };
    async function userRegeistration(value) {
        config.data =JSON.stringify(value);
        config.url = url;
        const result = await axios(config);
        return(result);
    }

    async function getUserDetails () {
        const result = await axios(url);
        return (result);
    }

    async function getEmployeeDetails (id) {
        const url = "http://localhost:3333/userDetails/" + id;
        const result = await axios(url);
        return result.data.employeeDetails;
    }

    async function getCurrentUserDetails (url) {
        const details = await axios(url);
        return details.data;
    }

    async function addEmployeeDetails (value, id) {
        const url = "http://localhost:3333/userDetails/" + id;
        const currentUser = await getCurrentUserDetails(url);
        if (!currentUser.employeeDetails) {
            currentUser.employeeDetails = [];
        }
        currentUser.employeeDetails.push(value);
        const result = await axios.put(url, JSON.stringify(currentUser));
        return(result.data.employeeDetails);
    }

    async function getCurrentEmployeeDetails (id, employeeId) {
        const url = "http://localhost:3333/userDetails/" + id;
        const currentUser = await getCurrentUserDetails(url);
        return currentUser.employeeDetails.filter(employee => employee.id === employeeId);
    }

    async function updateEmployeeDetails(id, employeeId, updatedData) {
        const url = "http://localhost:3333/userDetails/" + id;
        const currentUser = await getCurrentUserDetails(url);
        const index = currentUser.employeeDetails.findIndex(employee => employee.id === employeeId);
        if (index !== -1) {
            currentUser.employeeDetails[index] = updatedData;
        }
        const result = await axios.put(url, JSON.stringify(currentUser));
        return result;
    }

    async function deleteEmployeeDetails(id, employeeId) {
        const url = "http://localhost:3333/userDetails/" + id;
        const currentUser = await getCurrentUserDetails(url);
        const index = currentUser.employeeDetails.findIndex(employee => employee.id === employeeId);
        if (index !== -1) {
            currentUser.employeeDetails.splice(index, 1);
        }
        const result = await axios.put(url, JSON.stringify(currentUser));
        return result;
      }

    return {
        userRegeistration, getEmployeeDetails, addEmployeeDetails, getCurrentEmployeeDetails, deleteEmployeeDetails, updateEmployeeDetails, getUserDetails 
    }
};