import { ref, reactive } from 'vue'
import { defineStore } from 'pinia'

export const userDetails = defineStore('userDetails',{
  state: () => ({
    companyName: ref(''),
    logo: ref(''),
    id: ref(''),
    employeeDetails: reactive(
      {
        id: ref(''),
        name: ref(''),
        dob: ref(''),
        address: ref(''),
        city: ref(''),
        state: ref(''),
        experience: {
          companyName: ref(''),
          fromDate: ref(''),
          endDate: ref(''),
          position: ref('')
        }
      }
    ),
    searchDetails: {
      searchValue: ref(''),
      selectValue: ref(''),
    }
  }),
  actions: {
    updateUserDetails (details: any) {
      this.companyName= details.companyName;
      this.logo = details.logo;
      this.id = details.id;
    },
    updateExperience(details: any) {
        const experience = this.employeeDetails.experience;
        experience.companyName = details.companyName,
        experience.fromDate = details.fromDate,
        experience.endDate = details.endDate,
        experience.position = details.position
    },
    updateEmployeeDetails(details: any) {
      this.employeeDetails.name = details.name;
      this.employeeDetails.dob = details.dob;
      this.employeeDetails.address = details.address;
      this.employeeDetails.city = details.city;
      this.employeeDetails.state = details.state;
      this.employeeDetails.id = details.id;
    },
    updateSearchDetails(details: any) {
      this.searchDetails.searchValue = details.searchValue;
      this.searchDetails.selectValue = details.selectValue;
    },
    reset () {
      this.employeeDetails=
        {
          id:  '',
          name: '',
          dob: '',
          address: '',
          city: '',
          state: '',
          experience: {
            companyName: '',
            fromDate: '',
            endDate: '',
            position: ''
          }
        }
    }
  },
  getters: {
    getExperience (): any {
      return this.employeeDetails.experience;
    }
  }
});
