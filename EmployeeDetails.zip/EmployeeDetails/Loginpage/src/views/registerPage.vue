<template>
  <div class="registerPage">
    <div class="register">
        <div v-if="toastShow">
            <toast :toastShow="toastShow" :toastMessage="toastMessage" :isSuccessToast="isSuccessToast"></toast>
        </div>
      <div style="width: 350px">
        <v-form @submit.prevent="onSubmit" style="margin: 16px">
            <v-text-field v-model="companyName" label="Company" persistent-hint type="input" :rules="companyNameValidation"></v-text-field>
            <v-text-field v-model="logo" label="Logo" type="url" persistent-hint :rules="logoValidation"></v-text-field>
            <v-text-field v-model="emailName" label="Email" type="email" persistent-hint :rules="emailValidation" placeholder="Enter the email"></v-text-field>
            <v-text-field v-model="passWord" label="Password" type="password" persistent-hint :rules="passwordValidation" placeholder="Enter the password"></v-text-field>
            <div class="register-button">
              <v-btn type="submit" class="submit">Register</v-btn>
            </div>
        </v-form>
      </div>
      <div style="text-align: center; margin: 12px 0px">(or)</div>
      <div class="login-link">
        <RouterLink id="login-link" :to ="{ name: 'Login' }">Login</RouterLink>
        <RouterView></RouterView>
      </div>
    </div>
  </div>
</template>

<script>
import { defineComponent, ref, reactive, toRefs } from 'vue';
import axios from '../axios/axios.js';
import toast from '../components/toast.vue';

export default defineComponent({
    components: {
        toast
    },
    setup() {
        let emailName = ref('');
        let passWord = ref('');
        let logo = ref('');
        let companyName = ref ('');
        let isEmailError= ref(false);
        let isPasswordError= ref(false);
        let isCompanyError= ref(false);
        let isLogoError= ref(false);
        let toastMessage = ref('');
        let toastShow = ref(false);
        let isSuccessToast = ref(false);
        const { userRegeistration, getUserDetails } = axios();

        const emailValidation = [(value) => {
            if (value) {
                const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
                if (emailRegex.test(value)) {
                    isEmailError.value = false;
                    return true;
                }
                isEmailError.value = true;
                return 'Enter the valid email address';
            }

            return 'The field is manitory';
            }
        ];

        const passwordValidation = [(value) => {
            if (value) {
                if (value.length >= 8) {
                    isPasswordError.value = false;
                    return true;
                }
                return 'Minimum 8 character needed'
            }
            isPasswordError.value = true;
            return 'The field is manitory';
        }];

        const logoValidation = [(value) => {
            if (value) {
                isLogoError.value = false;
                return true;
            }
            isLogoError.value = true;
            return 'The logo is manitory';
        }];

        const companyNameValidation = [(value) => {
            if (value) {
                isCompanyError.value = false;
                return true;
            }
            isCompanyError.value = true;
            return 'The company name is required'
        }];

        const onSubmit = async() => {
             toastShow.value = false;
            if (!isEmailError.value && !isPasswordError.value && !isCompanyError.value && !isLogoError.value) {
                const userDetails = await getUserDetails();
                const data = userDetails.data;
                data.forEach(detail => {
                    if (detail.email === emailName.value) {
                         toastShow.value = true;
                         toastMessage.value = "Email already regeistered";
                         return;
                    }
                });
                if (!toastShow.value) {
                    const details = {
                    companyName:  companyName.value,
                    logo: logo.value,
                    email: emailName.value,
                    passWord: passWord.value
                    }
                    const result = await userRegeistration(details);
                    if (result.status === 201) {
                        toastShow.value = true;
                        isSuccessToast.value = true;
                        toastMessage.value = "RegeisterSuccessfully";
                        setTimeout(() => {
                            document.getElementById('login-link').click();
                        }, 1000); 
                    }
                }
            }
        }

        return {
            emailName,
            passWord,
            companyName,
            logo,
            emailValidation,
            logoValidation,
            passwordValidation,
            companyNameValidation,
            onSubmit,
            toastShow,
            toastMessage,
            isSuccessToast 
        }
    },
})
</script>
