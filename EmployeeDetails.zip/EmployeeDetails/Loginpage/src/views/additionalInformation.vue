<template>
<div style="margin: 16px;color: white">
    <div style="font-weight: 500; font-size: 18px; margin-bottom: 16px">Span Technology</div>
    <div>
        <span>Our employees are the ones who are the pillars of our company. They make our products successful and help our customers succeed.

            I strongly believe in our employees and want SPAN Technology to be a company that our employees and customers can be proud of. My goal is to make SPAN Technology a great place to work and create products that exceed our customers' expectations.

            "You have to be burning with an idea, or a problem, or a wrong that you want to right. If you're not passionate enough from the start, you'll never stick it out." - Steve Jobs
        </span>
    </div>
</div>
</template>
