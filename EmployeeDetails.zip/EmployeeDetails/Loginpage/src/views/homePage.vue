<template>
    <div id="homePage">
        <div class="header">
            <div class="compane-name">{{ state.companyName }}</div>
            <div style="display: flex;justify-content: end;width: 100%;">
                <div class="logo">
                    <v-img
                        :width="50"
                        :src="state.logo"
                    ></v-img>
                </div>
                <div class="logout" @click="logoutClick">
                    <i class="material-icons">logout</i>
                </div>
                <div class="additional-information" @click="additionalInformationClick">
                    <v-tooltip :text="state.companyName" location="bottom">
                        <template v-slot:activator="{ props }">
                            <div v-bind="props">
                                <i class="material-icons" style="background-color: green; height: 26px">account_circle</i>
                            </div>
                        </template>
                    </v-tooltip>
                </div>
                <div class="home-icon" @click="homePageClick">
                    <i class="material-icons" style="height: 26px">home</i>
                </div>
            </div>
        </div>
        <div class="body">
            <div style="height: 100px; display: flex; justify-content: center; align-items: center">
                <v-btn type="submit" @click="AddEmploee"> Add Employee</v-btn>
                <div v-if="isAddEmployee">
                    <AddEmploee :dialogOpen="isAddEmployee" @dialogClose="dialogClose" :isEditAction="false"></AddEmploee>
                </div>
            </div>
            <div v-if="isLogoutClicked">
                <logoutComponent :dialogOpen="isLogoutClicked" @dialogClose="dialogClose"></logoutComponent>
            </div>
            <div class="employeeDetails">
                <div id="Grid">
                    <div style="display: flex; justify-content: end; left: 71%; position: relative; width:250px">
                        <v-text-field style="width: 200px; background-color: white" type="text" id="filter-text-box" placeholder="Search" @click="searchClick"></v-text-field>
                        <div v-if="isSearchClicked">
                            <searchComponent :dialogOpen="isSearchClicked" @closeDialog="dialogClose" @applySearch="applySearch"></searchComponent>
                        </div>
                    </div>
                    <grid style="height: 400px; padding: 32px; width: 1000px" :class="themeClass"
                        :rowData="rows"
                        :columnDefs="columns"
                        :defaultColDef="defaultColumnDef"
                        @grid-ready="onGridReady"
                    ></grid>
                </div>
            </div>
        </div>
        <div>
            <RouterLink id="home-link" :to ="{ name: 'Home' }" style="display: none"></RouterLink>
            <RouterLink id="information-link" :to ="{ name: 'AdditionalInformation' }" style="display: none"></RouterLink>
            <RouterView></RouterView>
        </div>
    </div>
</template>

<script>
import { defineComponent, ref, reactive, provide, defineEmits } from 'vue';
import { AgGridVue } from 'ag-grid-vue3';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-quartz.css';
import AddEmploee from '../components/addEmployee.vue';
import Action from '../components/Action.vue';
import axios from '../axios/axios.js';
import { userDetails } from '../stores/userDetails';
import commonMethod from '../script/commonMethod';
import logoutComponent from '../components/lagout.vue';
import searchComponent from '../components/search.vue';

export default defineComponent({
    components: {
        grid: AgGridVue,
        AddEmploee,
        Action,
        logoutComponent,
        searchComponent
    },
    setup () {
        let isAddEmployee = ref (false);
        let rows = reactive([]);
        let { getEmployeeDetails } = axios();
        let { mapData } = commonMethod();
        let state = userDetails();
        let gridInstance = ref(null);
        let isLogoutClicked = ref(false); 
        let isSearchClicked = ref(false);
        let searchDetails = reactive({});
        provide('gridInstance', gridInstance);
        const columns = [
            { headerName: "S.No", field:"", valueFormatter: renderSerialNumber, width: '80px' },
            { headerName: "Name", field: "name" },
            { headerName: "DOB", field: "dob" },
            { headerName: "Address", field: "address" },
            { headerName: "City", field: "city" },
            { headerName: "State", field: "state" },
            { headerName: "Experience", field: "experience" },
            { headerName: "Action", field: "action",  cellRenderer: Action}
        ];
        const gridStyle = {
            height: '800px'
        }
        const defaultColumnDef = {
            width: '120px',
            filter: true,
            floatingFilter: true
        }
        const themeClass = "ag-theme-quartz";
        function renderSerialNumber (params) {
            return parseInt(params.node.id) + 1;
        }
        async function onGridReady (params) {
            gridInstance.value  =params.api;
            await getEmployeeDetails(state.$state.id).then(data => {
                params.api.setGridOption('rowData', mapData(data, state.$state.searchDetails));
            });
            setTimeout(() => {
                const element = document.getElementsByClassName('ag-overlay-no-rows-center');
                if (element) {
                    element[0].textContent = "No data available";
                }
            }, 0);
        };

        function AddEmploee () {
            isAddEmployee.value = true;
            state.reset();
        }
        function homePageClick (){
            document.getElementById('home-link').click();
        }
        function logoutClick () {
            if (isLogoutClicked.value) {
                isLogoutClicked.value = false;
            } else {
                isLogoutClicked.value = true;
            }
        }
        function searchClick() {
            if (isSearchClicked.value) {
                isSearchClicked.value = false;
            } else {
                isSearchClicked.value = true;
            }
        }
        function additionalInformationClick () {
            document.getElementById('information-link').click();
        }
        async function dialogClose () {
            isAddEmployee.value = false;
            isSearchClicked.value = false;
            if(!isLogoutClicked.value) {
                await getEmployeeDetails(state.$state.id).then(data => {
                    gridInstance.value.setGridOption('rowData', mapData(data, state.$state.searchDetails));
                });
            }
            isLogoutClicked.value = false;
        }
        async function applySearch (value) {
            isSearchClicked.value = false;
            searchDetails.value = {
                'searchValue': value.searchValue,
                'selectValue': value.selectValue
            };
            state.updateSearchDetails(searchDetails.value);
            await getEmployeeDetails(state.$state.id).then(data => {
                    gridInstance.value.setGridOption('rowData', mapData(data, state.$state.searchDetails));
            });
        }
        return {
            renderSerialNumber,
            columns,
            rows,
            gridStyle,
            themeClass,
            defaultColumnDef,
            onGridReady,
            AddEmploee,
            isAddEmployee,
            homePageClick,
            logoutClick,
            additionalInformationClick,
            dialogClose,
            state,
            isLogoutClicked,
            searchClick,
            isSearchClicked,
            applySearch
        }
    },
})
</script>

<style>
.employeeDetails {
    display: flex;
    justify-content: center;
}
#homePage .header {
    height: 56px;
    background-color: darkblue;
    color: white;
    display: flex;
    padding: 16px;
    align-items: center;
}
.logout, .logo, .additional-information {
    margin-right: 12px;
}
.additional-information, .logout, .home-icon{
    cursor: pointer;
}
#Grid .v-input__details {
    display: none !important;
}
#filter-text-box{
    padding: 4px 16px !important;
    min-height: 40px !important;
}
</style>
