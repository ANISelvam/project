<template>
  <div class="loginPage">
    <div class="login">
      <div style="width: 350px;">
        <div v-if="toastShow">
          <toast :toastShow="toastShow" :toastMessage="toastMessage" :isSuccessToast="isSuccessToast"></toast>
        </div>
        <v-form @submit.prevent="onSubmit" style="margin: 16px">
            <v-text-field v-model="emailName" label="Email" type="email" persistent-hint :rules="emailValidation" placeholder="Enter the email"></v-text-field>
            <v-text-field v-model="password" label="Password" type="password" persistent-hint :rules="passwordValidation" placeholder="Enter the password"></v-text-field>
            <div class="login-button">
              <v-btn type="submit" class="submit">Login</v-btn>
            </div>
        </v-form>
      </div>
      <div style="text-align: center; margin: 12px 0px">(or)</div>
      <div class="register-link">
        <RouterLink :to ="{ name: 'Register' }">Register</RouterLink>
        <RouterLink id="home-link" :to ="{ name: 'Home' }" style="display: none"></RouterLink>
        <RouterView></RouterView>
      </div>
    </div>
  </div>
</template>

<script>
import { defineComponent, ref } from 'vue';
import axios from '../axios/axios';
import commonMethod from '../script/commonMethod';
import toast from '../components/toast.vue';
import { userDetails } from '../stores/userDetails';

export default defineComponent({
  components: {
    toast
  },
  setup() {
    let emailName = ref('');
    let password = ref('');
    let isEmailError= ref(false);
    let isPasswordError= ref(false);
    let toastShow = ref(false);
    let isSuccessToast = ref(false);
    let toastMessage = ref('');
    let {updateUserDetails} = userDetails();
    const { validateEmail } = commonMethod();
    const { getUserDetails } = axios();

    const emailValidation = [(value) => {
        const result = validateEmail(value);
        if (result !== true) {
          isEmailError.value = true;
          return result;
        }

        isEmailError.value = false;
        return true;
    }];

    const passwordValidation = [(value) => {
      if (!value) {
        isPasswordError.value = true;
        return 'The field is manitory';
      }
      isPasswordError.value = false;
      return true;
    }];

const onSubmit = async (event) => {
  toastShow.value = false;
  if (!isEmailError.value && !isPasswordError.value) {
      const details = await getUserDetails();
      const data = details.data;
      data.forEach(detail => {
        if (detail.email === emailName.value) {
          if (detail.passWord === password.value) {
            updateUserDetails(detail);
            toastShow.value = true;
            isSuccessToast.value = true;
            toastMessage.value = "Login Successflly";
            setTimeout(() => {
              document.getElementById('home-link').click();
            }, 1000);
            return;
          }
          toastShow.value = true;
          toastMessage.value = "Incorrect password";
          return;
        }
      });
      if (!toastShow.value) {
        toastShow.value = true;
        toastMessage.value = "Email is not registerd";
        return;
      }
  }
}

  
    return {
      emailValidation,
      passwordValidation,
      emailName,
      password,
      onSubmit,
      toastShow,
      toastMessage,
      isSuccessToast
    }
  },
})
</script>

<style>
 .submit {
    background-color: white;
    color: blue;
    border: 1px solid blue;
 }
</style>
