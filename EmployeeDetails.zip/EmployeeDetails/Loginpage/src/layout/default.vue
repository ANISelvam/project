<template>
<div id="AllPage">
    <div class="body">
        <RouterLink to='/'></RouterLink>
        <RouterView></RouterView>
    </div>
</div>
</template>

<script>
import { defineComponent, onMounted, toRefs } from 'vue';
import {userDetails} from '../stores/userDetails';

export default defineComponent({
    setup() {
        let { companyName, logo }  = toRefs(userDetails());
        return {
            companyName,
            logo
        }
    },
})
</script>

<style>
#AllPage {
   background-color: #112A46;
  overflow: hidden;
  height: 642px;
}

</style>
