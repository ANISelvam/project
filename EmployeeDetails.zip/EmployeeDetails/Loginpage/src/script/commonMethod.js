export default function commonMethod() {
    function validateEmail (value) {
        if (value) {
            const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
            if (emailRegex.test(value)) {
                return true;
            }
            return 'Enter the valid email address';
        }

        return 'The field is manitory';
    }

    function validateInputs (value) {
        if (value) {
            return true;
        }

        return 'The field is manitory';
    }

    function mapData (details, searchDetails) {
        const rows = [];
        details.forEach(detail => {
         const obj = {
            name: detail.name,
            dob: detail.dob,
            address: detail.address,
            state: detail.state,
            city: detail.city,
            experience: detail.experience.position,
            id: detail.id
        }
        if (searchDetails.selectValue && searchDetails.searchValue) {
            Object.keys(obj).forEach(key => {
                if (searchDetails.selectValue.toLowerCase() === key) {
                    if (obj[key].toLowerCase().includes(searchDetails.searchValue.toLowerCase())) {
                        rows.push(obj);
                    }
                }
            });   
        } else {
            rows.push(obj);
        }
        });

        return rows;
    }


    return { validateEmail, validateInputs, mapData };
}