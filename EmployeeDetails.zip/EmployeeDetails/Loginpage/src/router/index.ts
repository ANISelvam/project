import { createRouter, createWebHashHistory, createWebHistory } from 'vue-router'
import Home from '../views/homePage.vue';
import Login from '../views/loginPage.vue';
import  Register from '../views/registerPage.vue';
import AdditionalInformation from '../views/additionalInformation.vue';

const routerDetails = [
  {
    path: '/',
    name: 'Login',
    component: Login
  },
  {
    path: '/register',
    name: 'Register',
    component: Register
  },
  {
    path: '/home',
    name: 'Home',
    component: Home
  },
  {
    path: '/additionalInformation',
    name: 'AdditionalInformation',
    component: AdditionalInformation
  }
  
]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: routerDetails
})

export default router
