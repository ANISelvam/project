<template>
    <div>
        <v-dialog id="dialogId" v-model="dialogOpen">
            <v-card style="width: 600px">
                <div style="margin: 16px">
                    <v-text-field type="input" label="Name" :rules="nameRules" v-model="name"></v-text-field>
                    <div>
                        <v-text-field label="DOB" @click="datePickerClick" v-model="dob" :rules="dobRules">
                        </v-text-field>
                        <div v-if="datePickerOpen">
                            <datepicker :datePickerOpen="datePickerOpen" @datePickerValue="updateDateValue"></datepicker>
                        </div>
                    </div>
                    <v-text-field type="input" label="Address" :rules="addressRules" v-model="address">
                    </v-text-field>
                    <v-select
                        v-model='city'
                        label="City"
                        :items="['Salem', 'Namakkal', 'Chennai', 'Coimbatore', 'Erodu', 'Hosur', 'Thiruchencode', 'karur', 'Rameshwaram', 'Madurai']"
                    ></v-select>
                    <v-text-field v-model="state" type="input" label="State" disabled>
                    </v-text-field>
                    <div>
                        <addExperience :isEditAction="isEditAction"></addExperience>
                    </div> 
                </div>
                <div style="float: right">
                    <div style="display: flex; justify-content: end; margin: 0px 16px 16px">
                    <v-btn type="submit" style="margin-right:12px" @click="cancelDialog">Cancel</v-btn>
                    <v-btn type="submit" class="add" @click="addEmployee"> {{isEditAction ? "Update" : "Add" }}</v-btn>
                    </div>
                </div>
            </v-card>
        </v-dialog>
    </div>
</template>

<script>
import { defineComponent, ref} from 'vue';
import addExperience from './addExperience.vue';
import axios from '../axios/axios';
import { userDetails } from '../stores/userDetails';
import datepicker from './datepicker.vue';
import commonValidation from '../script/commonMethod';

export default defineComponent({
    emit:['dialogClose'],
    components: {
        addExperience,
        datepicker
    },
    props: {
        dialogOpen: false,
        isEditAction: false
    },
    setup (props, { emit}) {
        const { addEmployeeDetails, updateEmployeeDetails, getParticularUserDetails } = axios();
        let store = userDetails();
        let { validateInputs } = commonValidation();
        const dialogOpen = ref(props.dialogOpen);
        const isEditAction = ref(props.isEditAction);
        const state = ref('TamilNadu');
        let datePickerOpen = ref (false);
        const employee = store.$state.employeeDetails;
        let dob = ref(employee.dob);
        let name = ref(employee.name);
        let city = ref(employee.city);
        let address = ref(employee.address);
        let isNameRequired = ref(false);
        let isDobRequired = ref(false);
        let isAddressRequired = ref(false);
        let isCityRequired = ref(false);
        function datePickerClick () {
            datePickerOpen.value = true;
        }
        function updateDateValue (value) {
            dob.value = value;
            datePickerOpen.value = false;
        }
        function cancelDialog () {
            dialogOpen.value = false;
            emit('dialogClose');
        }
        async function addEmployee () {
            if (!isDobRequired.value && !isAddressRequired.value && !isCityRequired.value && !isNameRequired.value) {
                const employeeDetails = {
                        id: Math.random().toString(36).substring(2),
                        name: name.value,
                        dob: dob.value,
                        address: address.value,
                        city: city.value,
                        state: state.value,
                        experience: store.getExperience
                }
                if(!isEditAction.value) {
                    await addEmployeeDetails(employeeDetails, store.$state.id);
                } else {
                    await updateEmployeeDetails(store.$state.id, store.$state.employeeDetails.id, employeeDetails);
                }

                emit('dialogClose');
            }
        }
        const nameRules = [(value) => {
           const result = validateInputs(value);
           isNameRequired.value = false;
           if (result !== true) {
                isNameRequired.value = true;
                return result;
           }

           return true;
        }];

        const dobRules = [(value) => {
           const result = validateInputs(value);
           isDobRequired.value = false;
           if (result !== true) {
                isDobRequired.value = true;
                return result;
           }

           return true;
        }];

        const cityRules = [(value) => {
           const result = validateInputs(value);
           isCityRequired.value = false;
           if (result !== true) {
                isCityRequired.value = true;
                return result;
           }

           return true;
        }];

        const addressRules = [(value) => {
           const result = validateInputs(value);
           isAddressRequired.value = false;
           if (result !== true) {
                isAddressRequired.value = true;
                return result;
           }

           return true;
        }];
        return {
            state,
            datePickerOpen,
            datePickerClick,
            dob,
            name,
            city,
            address,
            updateDateValue,
            cancelDialog,
            addEmployee,
            dialogOpen,
            nameRules,
            addressRules,
            cityRules,
            dobRules,
            isEditAction
        }
    }
})
</script>

<style>
#dialogId {
    left: calc((100% - 600px)/2);
}
#dialogId .add {
    background-color: white;
    color: blue;
    border: 1px solid blue;
}
</style>
