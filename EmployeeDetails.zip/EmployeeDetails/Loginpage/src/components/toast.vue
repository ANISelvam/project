<template>
<div>
    <div v-if="isToastShow" id="toast" v-bind:class="isSuccessToast ? 'success':'failure'" style="height: 32px; display: flex" @click="closeToast" >
        <div>{{ toastMessage }}</div>
        <span class="material-symbols-outlined" style="padding-left:12px; cursor: pointer">
                <i class="material-icons">cancel</i>
        </span>
    </div>
    </div>
</template>

<script>
import { defineComponent, onMounted, ref } from 'vue';

export default defineComponent({
    props: {
        toastShow: false,
        toastMessage: '',
        isSuccessToast: false,
    },
    setup (props) {
        const isToastShow = ref(props.toastShow); 
        const isSuccessToast = ref(props.isSuccessToast);
        function closeToast () {
            isToastShow.value = false;
        }
        onMounted(() => {
            document.addEventListener('click', function () {
                isToastShow.value = false;
            })
        })
        return {
            closeToast,
            isToastShow,
            isSuccessToast
        }
    }
})
</script>

<style>
#toast {
  position: fixed;
  top: 20px;
  left: 50%;
  transform: translateX(-50%);
  padding: 4px 20px;
  border-radius: 5px;
  z-index: 1000;
  transition: opacity 0.5s ease;
  border-color: rgb(32, 11, 11);
  height: 32px;
  width: auto;
  font-size: 16px;
  font-weight: 200;
  cursor: pointer;
}
.success {
    background-color: white;
    border: 1px solid blue;
    color: blue;
}
.failure{
    background-color: white;
    border: 1px solid red;
    color: red;
}
</style>
