<template>
<div>
    <v-dialog id="datePicker" v-model="datePickerOpen">
    <div>
        <v-date-picker v-model="datePickerValue" style="width: 350px">
        </v-date-picker>
        <div class="ApplyButton">
            <v-btn id="datePickerButton" type="submit" @click="datePickerApply">Apply</v-btn>
        </div>
    </div>
    </v-dialog>
</div>
</template>
<script>
import { defineComponent, ref} from 'vue';;

export default defineComponent({
    emit: ['datePickerValue'],
    props: {
        datePickerOpen: false
    },
    setup( props, { emit }) {
        let datePickerOpen = ref(props.datePickerOpen);
        let datePickerValue = ref (new Date());
        function datePickerApply(value){
            const date = datePickerValue.value.getDate() + "/" + (datePickerValue.value.getMonth() + 1) + "/" + datePickerValue.value.getFullYear();
            emit('datePickerValue', date)
        }
        return {
            datePickerOpen,
            datePickerApply,
            datePickerValue
        }
    },
})
</script>

<style>
#datePicker {
    left: calc((100% - 350px)/2);
    right: calc((100% - 350px)/2);
}
.ApplyButton {
    width: 350px;
    background-color: white;
    border-bottom-right-radius: 4px;
    border-bottom-left-radius: 4px;
    display: flex;
    justify-content: center;
    padding-bottom: 16px;
}
#datePickerButton {
    background-color: white;
    color: blue;
    border: 1px solid blue;
}
</style>
