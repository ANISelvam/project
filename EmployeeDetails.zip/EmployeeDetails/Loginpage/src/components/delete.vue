<template>
    <div>
        <v-dialog v-model="dialogOpen" class="delete-dialog">
            <v-card style="width: 500px; padding: 16px">
            <div style="margin-bottom: 16px"> {{ deleteContent }} </div>
            <div style="display: flex; justify-content: end;">
                <v-btn type="submit" class="delete" @click="deleteEmployeeDetail"> Confirm </v-btn>
                <v-btn type="submit" @click="cancel" style="margin-left: 12px"> Cancel </v-btn>
            </div>
            </v-card>
        </v-dialog>
    </div>
</template>

<script>
import { defineComponent, ref } from 'vue';
import { userDetails } from '../stores/userDetails';
import axios from '../axios/axios'

export default defineComponent({
    emit: ['dialogClose'],
    props: {
        dialogOpen: false
    },
    setup(props, {emit}) {
        const dialogOpen = ref(props.dialogOpen);
        const deleteContent = ref("Are you confirm the deleting the employee details?");
        const store = userDetails();
        const { deleteEmployeeDetails } = axios();
        async function deleteEmployeeDetail () {
            await deleteEmployeeDetails(store.$state.id, store.$state.employeeDetails.id);
            emit('dialogClose');
        }
        function cancel () {
            emit('dialogClose');
        }
        return {
            dialogOpen,
            deleteContent,
            deleteEmployeeDetail,
            cancel
        }
    },
})
</script>

<style>
.delete-dialog {
    left: calc((100% - 500px)/2);
    padding: 16px;
}
.delete {
    color: white;
    background-color: red;
}
</style>
