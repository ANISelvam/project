<template>
    <div style="display: flex; align-items: center">
        <div @click="editAction" style="height: 32px; padding: 4px 0px">
            <span class="material-symbols-outlined edit">
                <i class="material-icons">edit</i>
            </span>
        </div>
        <div @click="deleteAction" style="height: 32px; padding: 4px 0px">
            <span class="material-symbols-outlined delete-icon" >
                <i class="material-icons">delete</i>
            </span>
        </div>
        <div @click="actionClick" style="height: 32px; padding: 4px 0px">
            <span class="material-symbols-outlined visibility">
                <i class="material-icons">visibility</i>
            </span>
        </div>
        <div v-if="isEditClick">
            <edit-employee :dialogOpen="true" :isEditAction="isEditClick" @dialogClose="dialogClose"></edit-employee>
        </div>
        <div v-if="isDeleteClick">
            <deleteEmployee :dialogOpen="isDeleteClick" @dialogClose="dialogClose"></deleteEmployee>
        </div>
        <div v-if="isActionClick">
            <experienceDialog :dialogOpen="isActionClick" @dialogClose="dialogClose"></experienceDialog>
        </div>
    </div>
</template>

<script>
import { defineComponent, ref, inject} from 'vue';
import axios from '../axios/axios';
import { userDetails } from '../stores/userDetails';
import editEmployee from './addEmployee.vue';
import deleteEmployee from './delete.vue';
import experienceDialog from './experience.vue'
import commonMethod from '../script/commonMethod';

export default defineComponent({
    props: {
    },
    components: {
        editEmployee,
        deleteEmployee,
        experienceDialog
    },
    setup(props) {
        let { mapData } = commonMethod();
        const gridInstance = inject('gridInstance');
        const rowDetails = props.params.data;
        const { getCurrentEmployeeDetails, getEmployeeDetails } = axios();
        const state = userDetails();
        let isEditClick = ref(false);
        let isDeleteClick = ref(false);
        let isActionClick = ref(false);
        async function editAction () {
            await getCurrentEmployeeDetail();
            isEditClick.value = true;
        }
        async function deleteAction () {
            await getCurrentEmployeeDetail();
            isDeleteClick.value = true;
        }
        async function actionClick () {
            await getCurrentEmployeeDetail();
            isActionClick.value = true;
        }
        async function getCurrentEmployeeDetail() {
            const result  = await getCurrentEmployeeDetails(state.$state.id, rowDetails.id);
            state.updateEmployeeDetails(result[0]);
            state.updateExperience(result[0].experience);
        }
        async function dialogClose() {
            isEditClick.value = false;
            isDeleteClick.value = false;
            if (!isActionClick.value) {
                await getEmployeeDetails(state.$state.id).then(data => {
                    gridInstance.value.setGridOption('rowData', mapData(data, state.$state.searchDetails));
                });
                setTimeout(() => {
                    const element = document.getElementsByClassName('ag-overlay-no-rows-center');
                    if (element) {
                        element[0].textContent = "No data available";
                    }
            }, 0);
            }
            isActionClick.value = false;
        }
        return {
            deleteAction,
            editAction,
            isEditClick,
            dialogClose,
            isDeleteClick,
            actionClick,
            isActionClick
        }
    },
})
</script>


<style>
.edit, .delete-icon {
    padding-right: 8px;
}
.edit {
    color: #5c93cc;
}
.delete-icon{
    color: #e45a43 !important;
}
.visibility {
    color: #e7a928;
}
</style>