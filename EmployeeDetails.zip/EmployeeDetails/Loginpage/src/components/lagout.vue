<template>
    <div>
        <v-dialog v-model="dialogOpen" class="logout-dialog">
            <v-card style="width: 500px; padding: 16px">
            <div style="margin-bottom: 16px"> {{ logoutContent }} </div>
            <div style="display: flex; justify-content: end;">
                <v-btn type="submit" class="logout" @click="logout"> Confirm </v-btn>
                <v-btn type="submit" @click="cancel" style="margin-left: 12px"> Cancel </v-btn>
            </div>
            </v-card>
        </v-dialog>
    </div>
</template>

<script>
import { defineComponent, ref } from 'vue';
import { userDetails } from '../stores/userDetails';

export default defineComponent({
    emit: ['dialogClose'],
    props: {
        dialogOpen: false
    },
    setup(props, {emit}) {
        const dialogOpen = ref(props.dialogOpen);
        const store = userDetails();
        const logoutContent = ref("Are you confirm to logout?");
        function logout () {
            dialogOpen.value = false;
            setTimeout(() => {
                store.reset();
                 window.location.href = "/";
            }, 1000);
        }
        function cancel () {
            emit('dialogClose');
        }
        return {
            dialogOpen,
            logoutContent,
            logout,
            cancel
        }
    },
})
</script>

<style>
.logout-dialog {
    left: calc((100% - 500px)/2);
    padding: 16px;
}
.logout {
    color: white;
    background-color: red;
    height: 26px;
}
</style>
