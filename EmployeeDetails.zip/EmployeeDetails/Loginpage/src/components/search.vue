<template>
    <div>
        <v-dialog v-model="dialogOpen" class="search-dialog">
            <v-card style="width: 300px; padding: 16px">
                <div>
                    <v-select label="Select" :items="['Name', 'Dob', 'Address', 'City', 'State', 'Experience', 'Action' ]" v-model="selectColumn">
                    </v-select>
                    <v-text-field label="Search" v-model="searchValue"></v-text-field>
                </div>
                <div style="display: flex; justify-content: end; margin-top: 16px;">
                    <v-btn type="sumbit" @click="closeDialog">close</v-btn>
                    <v-btn type="submit" class="apply-search" @click="applySearch">Search</v-btn>
                </div>
            </v-card>
        </v-dialog>
    </div>
</template>

<script>
import { defineComponent, ref } from "vue";
import { userDetails } from "../stores/userDetails";

export default defineComponent ({
    emit: ['closeDialog', 'applySearch'],
    props: {
        dialogOpen: false
    },
    setup(props, {emit}) {
        const dialogOpen = ref(props.dialogOpen);
        const store = userDetails();
        let searchValue = ref(store.$state.searchDetails.searchValue);
        let selectColumn = ref(store.$state.searchDetails.selectValue);
        function closeDialog () {
            emit('closeDialog');
        }
        function applySearch() {
            emit('applySearch', { "searchValue": searchValue.value, "selectValue": selectColumn.value})
        }
        return {
            dialogOpen,
            searchValue,
            selectColumn,
            closeDialog,
            applySearch
        }
    }

});
</script>

<style>
.search-dialog {
    left: calc((100% - 300px)/2);
    padding: 16px;
}
.apply-search{
    color: white;
    background-color: blue;
    margin-left: 12px;
}
.search-dialog .v-input__details {
    display: none !important;
}
</style>
