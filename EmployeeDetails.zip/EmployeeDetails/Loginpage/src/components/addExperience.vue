<template>
    <div class="experienceDialog">
        <div style="margin-bottom: 12px">Add Experience</div>
        <div>
            <v-text-field type="input" label="Company Name" v-model="companyName" :disabled="isDisabled"></v-text-field>
            <div>
                <v-text-field label="From Date" @click="fromDatePickerInput" v-model="fromDate" :disabled="isDisabled"></v-text-field>
                <div v-if="fromDatePickerOpen">
                    <datepicker :datePickerOpen="fromDatePickerOpen" @datePickerValue="updateDateValue"></datepicker>
                </div>
            </div>
            <div>
                <v-text-field label="End Date" @click="endDatePickerInput" v-model="endDate" :disabled="isDisabled"></v-text-field>
                <div v-if="endDatePickerOpen">
                    <datepicker :datePickerOpen="endDatePickerOpen" @datePickerValue="updateDateValue"></datepicker>
                </div>
            </div>
            <div>
                <div style="margin-bottom: 12px">Position:</div>
                <div>
                    <input id="quality" type="radio" v-model="qualityAnalyst" @change="positionChange" :disabled="isDisabled"/>
                    <label class="radio-child">Quality Analyst</label>
                </div>
                <div>
                    <input id="developer" type="radio" v-model="developer" @change="positionChange" :disabled="isDisabled"/>
                    <label class="radio-child">Developer</label>
                </div>
                <div>
                    <input id="business" type="radio" v-model="businessAnalyst" @change="positionChange" :disabled="isDisabled" />
                    <label class="radio-child">Businees Analyst</label>
                </div>
            </div>
        </div>
        <div>
            <div style="display: flex; justify-content: center; margin-right: 16px">
            <v-btn type="submit" class="submit" @click="addExperience" :disabled="isDisabled"> {{ isEditAction ? "Update Experience" : "Add Experience"}}</v-btn>
            </div>
        </div>
    </div>
</template>
<script>
import { defineComponent, ref } from 'vue';
import { userDetails } from '../stores/userDetails';
import datepicker from './datepicker.vue';

export default defineComponent({
    components: {
        datepicker
    },
    props: {
        isEditAction: false
    },
    setup(props) {
        let store = userDetails();
        let dialogOpen = ref(true);
        const isEditAction = ref(props.isEditAction);
        let fromDatePickerOpen = ref(false);
        let endDatePickerOpen = ref(false);
        const experienceDetails = store.$state.employeeDetails.experience;
        let fromDate = ref(experienceDetails.fromDate);
        let endDate = ref(experienceDetails.endDate);
        let companyName = ref(experienceDetails.companyName);
        let qualityAnalyst = experienceDetails.position === "Quality Analyst" ? ref('on') : ref('off');
        let developer = experienceDetails.position === "Developer" ? ref('on') : ref('off');
        let businessAnalyst = experienceDetails.position === "BusinessAnalyst" ? ref('on') : ref('off');
        let position = ref ('');
        let isDisabled = ref(false);
        function fromDatePickerInput() {
            fromDatePickerOpen.value = true;
        }
        function endDatePickerInput() {
            endDatePickerOpen.value = true;
        }
        function updateDateValue (value) {
            if (fromDatePickerOpen.value) {
                fromDate.value = value;
                fromDatePickerOpen.value = false;
            } else {
                endDate.value = value;
                endDatePickerOpen.value = false;
            }
        }
        function addExperience () {
            const experience = {
                companyName: companyName.value,
                fromDate: fromDate.value,
                endDate: endDate.value,
                position: position.value
            }
            store.updateExperience(experience);
            isDisabled.value = true;
        }
        function positionChange (params) {
            const target = params.target;
            position.value = '';
            qualityAnalyst.value = 'off';
            businessAnalyst.value = 'off';
            developer.value = 'off';
            if (target.value === 'on') {
                if (target.id === 'quality') {
                    position.value = "Quality Analyst";
                    qualityAnalyst.value = 'on';
                } else if (params.target.id === 'developer') {
                    position.value = "Developer";
                    developer.value = 'on';
                } else {
                    position.value = "Business Analyst";
                    businessAnalyst.value = 'on';
                }
            }
        }
        return {
            dialogOpen,
            qualityAnalyst,
            developer,
            businessAnalyst,
            fromDatePickerInput,
            endDatePickerInput,
            updateDateValue,
            endDatePickerOpen,
            fromDatePickerOpen,
            fromDate,
            endDate,
            companyName,
            addExperience,
            positionChange,
            isDisabled,
            isEditAction
        }
    },
})
</script>

<style>
.experienceDialog {
    background-color: aliceblue;
    padding: 16px;
}
.experienceDialog .radio-child{
    padding-left: 12px;
}
.experienceDialog .submit {
    background-color: white;
    color: blue;
    border: 1px solid blue;
}
</style>
