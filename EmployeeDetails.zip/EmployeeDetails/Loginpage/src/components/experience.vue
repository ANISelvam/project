<template>
    <div>
        <v-dialog v-model="dialogOpen" class="detail-dialog">
            <v-card style="width: 300px; padding: 16px">
                <div>
                    <span>Experience Details:</span>
                <div>
                    <span>Comapany Name:</span>
                    <span class="span-details">{{ experienceDetails.companyName }}</span>
                </div>
                <div>
                    <span>From Date:</span>
                    <span class="span-details">{{ experienceDetails.fromDate }}</span>
                </div>
                <div>
                    <span>End Date:</span>
                    <span class="span-details">{{ experienceDetails.endDate }}</span>
                </div>
                <div>
                    <span>Position:</span>
                    <span class="span-details">{{ experienceDetails.position }}</span>
                </div>
                </div>
                <div style="margin: 16px 16px 0px; display: flex; justify-content: end">
                    <v-btn type="sumbit" @click="closeDialog">Cancel</v-btn>
                </div>
            </v-card>
        </v-dialog>
    </div>
</template>

<script>
import { defineComponent, ref } from 'vue';
import { userDetails } from '../stores/userDetails';

export default defineComponent({
    emit:['dialogClose'],
    props: {
        dialogOpen: false
    },
    setup(props, {emit}) {
        const dialogOpen = ref(props.dialogOpen);
        const store = userDetails();
        const experienceDetails = ref(store.getExperience);
        function closeDialog () {
            emit('dialogClose');
        }
        return {
            dialogOpen,
            experienceDetails,
            closeDialog
        }
    },
})
</script>

<style>
.span-details {
    padding-left: 12px;
}
.detail-dialog {
    left: calc((100% - 300px)/2);
}
</style>
